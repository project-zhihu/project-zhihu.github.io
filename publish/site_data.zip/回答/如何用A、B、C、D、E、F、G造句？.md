A badged ace fed a bee aged cabbage.
一个戴勋章的老兵给蜜蜂喂了发酵的白菜。

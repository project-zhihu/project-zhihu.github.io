这个事件的核心争议在于，竟然有人正确使用了持枪权。
原本的状况是，很多美国人也一直希望控枪，压缩普通人的暴力权。
所以才会频频渲染校园枪击事件，给共产党递刀子。
加上共产党添油加醋，恶意宣传，给中国人形成了一种美国天天枪击犯罪的印象。

美国人并不害怕给共产党递刀子，反而认为和共产党一起骂美国，能促进这种损害自身权力的改革。
这样才能早日放弃自由人的身份，像中国人一样稳稳地做奴隶。

> Apparently about 30% of the population wants that too. They dream of being a slave for some group of oligarchs, it seems like it should be impossible, but I suppose some people must have some innate slave-desire to just be told what to do and have a neatly organized and non-complex traditional framework to operate in, so they dont have to think, plan, or make decisions for themselves. Only to obey the man in the castle. I suppose thousands of years of subjugation under lords and kings has made some portion of the population like this.

> 我看起码三成的人都是如此，每天梦寐以求当寡头独裁者的奴隶。我们总觉得不会有人不喜欢自由，问题是我看某些人内心有一种奴隶倾向，巴不得每天有人把自己安排的明明白白，这样就不需要思考，不需要计划，不需要选择人生。反正听话就好了。几千年国王大公征服那么多人不是白征服的。

万万没想到，竟然有人把持枪权用在了正确的地方。
这可太可怕了，在当今这个世界德性大衰败的环境里显得格格不入。

不仅武德充沛，还要左有左，杀的是资本家；要右有右，使用的是持枪权。
这种人的存在是美国乃至世界的福气，然而恰恰是现代社会不可容忍之善。

所以，绝对不能让这位刺客逍遥法外，不然实在是，太可怕了，太可怕了。
